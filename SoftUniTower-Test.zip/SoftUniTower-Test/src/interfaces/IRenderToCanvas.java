package interfaces;

import java.awt.Graphics;

/**
 * Created by oxana_bs on 4.7.2016 г..
 */
public interface IRenderToCanvas {
    void render(Graphics g);
}

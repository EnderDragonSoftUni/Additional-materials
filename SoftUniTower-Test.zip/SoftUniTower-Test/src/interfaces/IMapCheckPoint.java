package interfaces;

/**
 * Created by oxana_bs on 4.7.2016 г..
 */
public interface IMapCheckPoint {

    /*
     * @param x
     * @param y
     * @return
     */
    boolean check(int x, int y);
}

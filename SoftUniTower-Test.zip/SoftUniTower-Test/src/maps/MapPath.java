package maps;

import graphics.BaseTile;

import java.awt.*;
import java.util.ArrayList;

/**
 * Класс хранит информацию пути перемещения элемента по карте.
 */
public class MapPath {

    /**
     * Список плиток по которым пролегает путь.
     */
    private ArrayList<Point> path;

    /**
     * Текущая точка.
     */
    public Point point;

    /**
     * Текущая позиция точки.
     */
    protected int index = 0;

    public MapPath() {
        this.path = new ArrayList<Point>();
    }

    /**
     * Очистить путь.
     */
    public void clear() {
        this.path.clear();
    }

    /**
     * Добавить точку по который будет проходить путь.
     *
     * @param p
     */
    public void add(Point p) {
        this.path.add(p);
    }

    /**
     * Указать начальную точку пути.
     *
     * @param posX
     * @param posY
     */
    public void startMove(int posX, int posY) {
        this.point = new Point(posX, posY);
        this.index = path.size() - 1;
    }

    /**
     * Проверить существует ли следующая точка.
     *
     * @return
     */
    public boolean hasNext() {
        return (this.index > -1);
    }

    /**
     * Перейти на следующую точку (в случаи если текущую уже прошли).
     *
     * @param step
     * @return
     */
    public Point nextPos(int step) {
        int x = path.get(index).x * BaseTile.SIZE,
                y = path.get(index).y * BaseTile.SIZE;
        if (point.x != x) {
            point.x += step * ((x < point.x) ? -1 : 1);
        }
        if (point.y != y) {
            point.y += step * ((y < point.y) ? -1 : 1);
        }

        if (point.x == x && point.y == y) {
            index--;
        }


        return point;
    }
}

package game;

import display.NameBox;
import display.Window;
import graphics.*;
import interfaces.IMapCheckPoint;
import maps.GemaMap;
import maps.*;
import objects.HighScore;
import objects.Player;
import objects.ProgressBar;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferStrategy;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Game extends Canvas implements Runnable {

    public static final int SCALE = 2;
    public static final int WIDTH = 320 * SCALE;
    public static final int HEIGHT = WIDTH / 12 * 9;
    public static final String TITLE = "Icy Tower+";
    private static final int TIME_DELAY = 100;
    public static int score = 0;
    public static Score currentScore;
    public static STATE gameState = STATE.Menu;
    protected int timeDelay = 100;

    private Menu menu;
    private HighScore highScore;
    public boolean running = false;
    private Thread thread;
    private Player player;
    private PlatformHandler platformHandler;
    private GiftHandler giftHandler;
    private ProgressBar progressBar;
    private LevelHandler levelHandler;
    private InputHandler inputHandler;
    private GemaMap map;
    private Labyrinth labyrinth;
    private MapPath mapPath;

    public int getScore() {
        return score;
    }

    public void setScore(int x) {
        this.score = score;
    }

    public enum STATE {
        Menu,
        Game,
        Credentials,
        Labyrinth,
        End
    }

    protected KeyAdapter keyListener = new KeyAdapter() {

        @Override
        public void keyPressed(KeyEvent e) {

            if (e.getKeyCode() == 37) {
                player.directionX = -1;
            }
            if (e.getKeyCode() == 39) {
                player.directionX = 1;
            }
            if (e.getKeyCode() == 38) {
                player.directionY = -1;
            }
            if (e.getKeyCode() == 40) {
                player.directionY = 1;
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            if (e.getKeyCode() == 37 || e.getKeyCode() == 39) {
                player.directionX = 0;
            }
            if (e.getKeyCode() == 38 || e.getKeyCode() == 40) {
                player.directionY = 0;
            }
        }
    };

    /**
     * Создаем путь до указанной точке.
     *
     * @param startX начальная точка по X.
     * @param startY начальная точка по Y.
     * @param endX   конечная точка по X.
     * @param endY   конечная точка по Y.
     * @return
     */

    /**
     * Реализация класса обработчика событий мыши.
     * Получает координаты щелчка по карте и определяет путь движения персонажа.
     */
    protected MouseAdapter mouseListener = new MouseAdapter() {

        @Override
        public void mouseClicked(MouseEvent e) {

            //получаем начальные координаты плиток
            int startTileX = (int) Math.floor((Math.abs(player.getX() - player.posRenderX) + e.getX()) / BaseTile.SIZE),
                    startTileY = (int) Math.floor((Math.abs(player.getY() - player.posRenderY) + e.getY()) / BaseTile
                            .SIZE);

            //создаем путь
            if (tileIsWalkable(startTileX, startTileY)) {
                MapPath mapPath = makePath(player.getX() / BaseTile.SIZE, player.getY() / BaseTile.SIZE, startTileX,
                        startTileY);
                player.mapPath = mapPath;
            }
        }
    };

    /**
     * Отвечает за запуск игры
     */
    public void startLabyrinth() {
        if (running) {
            return;
        }
        running = true;
        labyrinth = new Labyrinth();

        player = new Player(WIDTH / 2 - 60, 345, 60, 70, platformHandler, giftHandler, progressBar);
        //Ставим карту
        setMap(1);
        //устанавливаем обработчики событий
        setListener();

        new Thread(this).start();
    }

    public Game() {
        Assets.init();
        this.platformHandler = new PlatformHandler();
        this.giftHandler = new GiftHandler();
        this.highScore = new HighScore(score);
        this.progressBar = new ProgressBar(this);
        this.levelHandler = new LevelHandler(this.platformHandler, this.giftHandler);
        this.labyrinth = new Labyrinth();
        platformHandler.addStartingPlatforms();
        giftHandler.addStartingGifts();
        player = new Player(WIDTH / 2 - 60, 345, 60, 70, platformHandler, giftHandler, progressBar);

        menu = new Menu(this, platformHandler);
        this.addMouseListener(menu);
        this.inputHandler = new InputHandler(this);

        new Window(WIDTH, HEIGHT, TITLE, this);
        new NameBox();
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    public MapPath makePath(int startX, int startY, int endX, int endY) {
        MapFindingPath mfp = new MapFindingPath();
        mfp.setcheckPoint(new IMapCheckPoint() {
            @Override
            public boolean check(int x, int y) {
                return tileIsWalkable(x, y);
            }
        });

        if (mfp.findPath(startX, startY, endX, endY)) {
            return mfp.getPath();
        }

        return null;
    }

    /**
     * Метод отвечает за установку карты.
     *
     * @param mapId Номер карты.
     */
    public void setMap(int mapId) {
        if (mapId == 1) {
            map = new Map1();
        } else if (mapId == 2) {
            map = new Map3();
        } else if (mapId == 3) {
            map = new Map2();
        }

        //удаляем путь при смене карты
        player.mapPath = null;

        //Данные хранения положения персонажа могут быть реализованы в классе карты
        player.setX(BaseTile.SIZE);
        player.setY(BaseTile.SIZE);
        //устанавливаем статическое позиционирование
        player.posRenderX = BaseTile.SIZE;
        player.posRenderY = BaseTile.SIZE;
    }

    private synchronized void stop() {
        if (!running) {
            return;
        }
        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(1);
    }

    public void run() {
        while (running) {
            long lastTime = System.nanoTime();
            double amountOfTicks = 20.0;
            double ns = 1000000000 / amountOfTicks;
            double delta = 0;
            long timer = System.currentTimeMillis();
            int frames = 0;
            while (running) {

                long now = System.nanoTime();
                delta += (now - lastTime) / ns;
                lastTime = now;

                try {
                    thread.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                while (delta >= 1) {
                    tick();
                    delta--;
                }
                if (running) {
                    render();
                }
                frames++;
                if (System.currentTimeMillis() - timer > 1000) {
                    timer += 1000;
                    System.out.println("FPS " + frames);
                    frames = 0;
                }
            }
            stop();
        }
    }

    public void stopLabyrinth() {
        //удаляем обработчики событий
        unSetListener();
        running = false;
    }

    public void runLabyrinth() {
        while (running) {
            try {
                TimeUnit.MILLISECONDS.sleep(timeDelay);
            } catch (InterruptedException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            }
            updateLabyrinth();
        }
    }

    /**
     * Установить обработчики  событий.
     */
    public void setListener() {
        labyrinth.setFocusable(true);//нужно указать для получения событий с клавиатуры
        labyrinth.addKeyListener(keyListener);
        labyrinth.addMouseListener(mouseListener);
    }

    /**
     * Удалить обработчики  событий.
     */
    public void unSetListener() {
        labyrinth.setFocusable(false);//убираем    фокус
        labyrinth.removeKeyListener(keyListener);
        labyrinth.removeMouseListener(mouseListener);
    }

    protected void updateLabyrinth() {

        checkingChangeMap();

        //добавляем на холст   элементы карты m
        labyrinth.removeRenders();
        int mapW = map.getWidth(),
                mapH = map.getHeight(),
                x, y, tileId,
                //ширина и высота   квадрата  - рамки в тайлах
                //размер зависит от экрана игры
                widthTile = 18,
                heightTile = 12,
                //центральная точка отображаемого квадрата карты
                cWidthTile = widthTile / 2 - 1,
                cHeightTile = heightTile / 2 - 1,
                //здвиг карты
                offsetX = (player.getX() - player.posRenderX) % BaseTile.SIZE,
                offsetY = (player.getY() - player.posRenderY) % BaseTile.SIZE,
                //ограничиваем выводимые плитки
                startTileX = (int) Math.floor(Math.abs(player.getX() - player.posRenderX) / BaseTile.SIZE),
                startTileY = (int) Math.floor(Math.abs(player.getY() - player.posRenderY) / BaseTile.SIZE),
                endTileX = widthTile + startTileX > mapW ? mapW : widthTile + startTileX,
                endTileY = heightTile + startTileY > mapH ? mapH : heightTile + startTileY;
        //определяем когда двигать карту - а когда должен двигаться  персонаж
        boolean movePlayerX = (player.getX() / BaseTile.SIZE < cWidthTile || mapW - player.getX() / BaseTile.SIZE <
                cWidthTile + 1),
                movePlayerY = (player.getY() / BaseTile.SIZE < cHeightTile || mapH - player.getY() / BaseTile.SIZE <
                        cHeightTile + 2);

        BaseTile tile;
        for (y = startTileY; y < endTileY; y++) {
            for (x = startTileX; x < endTileX; x++) {
                tileId = map.getTileId(x, y);
                tile = BaseTile.getTileById(tileId);

                tile.setPosX((x - startTileX) * BaseTile.SIZE);
                tile.setPosY((y - startTileY) * BaseTile.SIZE);
                tile.setPosX(tile.getPosX() - offsetX);
                tile.setPosY(tile.getPosY() - offsetY);

                labyrinth.addRender(tile);
            }
        }

        //добавляем персонажа
        labyrinth.addRender(player);
        //изменяем положение персонажа
        //для этого мы должны сделать проверку на возможность движения.
        if ((player.directionX != 0 || player.directionY != 0) && accessMove()) {
            player.setX(player.getX() + player.directionX * player.THISVELOCITY);
            player.setY(player.getY() + player.directionY * player.THISVELOCITY);

            if (movePlayerX) {
                player.posRenderX += player.directionX * player.THISVELOCITY;
            }
            if (movePlayerY) {
                player.posRenderY += player.directionY * player.THISVELOCITY;
            }
        }
        //вызываем перерисовку холста
        labyrinth.repaint();
    }

    /**
     * Проверяем находиться ли пользователь на плитки с дверью.
     */
    public void checkingChangeMap() {
        int tileX = player.getX() / BaseTile.SIZE,
                tileY = player.getY() / BaseTile.SIZE,
                tileId = map.getTileId(tileX, tileY);
        BaseTile tile = BaseTile.getTileById(tileId);
        if (tile.door > 0) {
            setMap(tile.door);
        }
    }

    /**
     * Проверяем возможность персонажа переместится.
     * <p>
     * В данной реализации, может случится, что объект не достигает границы плитки, а идти уже не может.
     * Причина вероятно в значении скорости игрока (player.speed), она должна делить без остатка размер плитки.
     * В противном случаи остаток нужно прибавить к максимальному  значению right и down.
     */
    protected boolean accessMove() {
        int left, right, top, down;
        boolean isWalkable = true;

        //верх и низ
        //Находим вероятные точки плиток с учетом направления directionY
        left = (int) Math.ceil((player.getX()) / BaseTile.SIZE);
        right = (int) Math.floor((player.getX() + player.getPlayerWidth() - 1) / BaseTile.SIZE);
        top = (int) Math.ceil((player.getY() + player.THISVELOCITY * player.directionY) / BaseTile.SIZE);
        down = (int) Math.floor((player.getY() + player.getPlayerHeight() + player.THISVELOCITY * player.directionY -
                1) / BaseTile.SIZE);
        //проверяем доступность направления по вершине правой и левой сверх (низу) - на тот случай если игрок
        // находится вне начала плитки по оси Х
        if (player.directionY == -1 && !(tileIsWalkable(left, top) && tileIsWalkable(right, top))) {
            isWalkable = false;
        } else if (player.directionY == 1 && !(tileIsWalkable(left, down) && tileIsWalkable(right, down))) {
            isWalkable = false;
        }
        //право и лево
        //Находим вероятные точки плиток с учетом направления directionX
        left = (int) Math.ceil((player.getX() + player.THISVELOCITY * player.directionX) / BaseTile.SIZE);
        right = (int) Math.floor((player.getX() + player.getPlayerWidth() + player.THISVELOCITY * player.directionX -
                1) / BaseTile.SIZE);
        top = (int) Math.ceil((player.getY()) / BaseTile.SIZE);
        down = (int) Math.floor((player.getY() + player.getPlayerHeight() - 1) / BaseTile.SIZE);
        //проверяем доступность направления по вершине верха и низа лева (права) - на тот случай если игрок находится
        // вне начала плитки по оси Y
        if (player.directionX == -1 && !(tileIsWalkable(left, top) && tileIsWalkable(left, down))) {
            isWalkable = false;
        } else if (player.directionX == 1 && !(tileIsWalkable(right, top) && tileIsWalkable(right, down))) {
            isWalkable = false;
        }

        return isWalkable;
    }

    private void tick() {
        if (gameState == STATE.Game) {
            player.tick();
            platformHandler.tick();
            giftHandler.tick();
            progressBar.tick();
            highScore.tick(score);
            if (Player.isDead) {
                currentScore = new Score(score);
                //currentScore.save();
                //currentScore.getTop3();
                Score.tick(currentScore);
                Game.gameState = STATE.End;
                Player.isDead = false;
                PlatformHandler.clearAllPlatforms();
                PlatformHandler.addStartingPlatforms();
                GiftHandler.clearAllGifts();
                GiftHandler.addStartingGifts();
                progressBar.setFillProgressBar(0);
                LevelHandler.setCurrentLevel(1);

                player = new Player(WIDTH / 2 - 60, 345, 60, 70, platformHandler, giftHandler, progressBar);
                InputHandler.beginning = true;
            }
        } else if (gameState == STATE.Menu) {
            menu.tick();
        }
    }

    private void render() {
        BufferStrategy bs = this.getBufferStrategy();
        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }
        Graphics g = bs.getDrawGraphics();

        if (gameState == STATE.Game || gameState == STATE.End) {
            levelHandler.render(g);
        } else {
            g.drawImage(Assets.background, 0, 0, Game.WIDTH, Game.HEIGHT, null);
        }

        if (gameState == STATE.Game) {
            player.render(g);
            platformHandler.render(g);
            giftHandler.render(g);
            highScore.render(g);
            progressBar.render(g);


        } else if (gameState == STATE.Menu) {
            this.score = 0;
            menu.render(g);
        } else if (gameState == STATE.End) {
            this.score = 0;
            menu.render(g);
            currentScore.render(g);
        } else if (gameState == STATE.Labyrinth) {
            startLabyrinth();
            player.renderInLabyrinth(g);
        }

        g.dispose();
        bs.show();
    }

    protected boolean tileIsWalkable(int x, int y) {
        BaseTile tile = BaseTile.getTileById(map.getTileId(x, y));
        return (tile != null && tile.isWalkable());
    }
}
/*
if (currentScore.getScore() == 500L) {
        gameState = STATE.Labyrinth;
        }*/

package graphics;

public class AnimationHandler {
}

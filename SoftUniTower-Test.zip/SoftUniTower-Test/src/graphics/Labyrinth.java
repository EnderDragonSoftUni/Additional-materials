package graphics;

import interfaces.IRenderToCanvas;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Created by oxana_bs on 4.7.2016 г..
 */
public class Labyrinth extends JPanel {

    /**
     * Основное изображение для рисования.
     * Осуществляет буферизацию изображений (избавляет от мерцания).
     */
    protected Image bufer = null;

    /**
     * Фон холста по умолчанию.
     */
    protected Color backGround = Color.black;

    /**
     * Список элементов, которые необходимо нарисовать на холсте.
     */
    protected ArrayList<IRenderToCanvas> renders = new ArrayList<>();

    /**
     * Добавить элемент для рисования.
     *
     * @param render
     */
    public void addRender(IRenderToCanvas render) {
        renders.add(render);
    }

    /**
     * Очищает список обрисовываемых элементов.
     */
    public void removeRenders() {
        renders.clear();
    }

    /**
     * Отвечает за вывод  графики на компоненте.
     *
     * @param g
     */
    public void paintLabyrinth(Graphics g) {
        g.clearRect(0, 0, getWidth(), getHeight());
        g.setColor(backGround);
        g.fillRect(0, 0, getWidth(), getHeight());

        for (IRenderToCanvas render : renders) {
            render.render(g);
        }
    }

    /**
     * Переопределяем метод обрисовки компонента.
     *
     * @param g
     */
    @Override
    public void paint(Graphics g) {
        super.paint(g);

        if (bufer == null) {
            bufer = createImage(getWidth(), getHeight());
        }
        //рисуем мир!
        paintLabyrinth(bufer.getGraphics());
        g.drawImage(bufer, 0, 0, null);
    }
}


package objects;


public enum  ID {
    Player,
    Gift,
    Door,
}

package venchGame.lesson1;
import javax.swing.*;
import java.awt.*;

/**
 * Класс персонажа игры.
 */
public class Player implements IRenderToCanvas {
    /**
     * Изображение персонажа
     */
    protected Image imageSrc;
    /**
     * Положение персонажа в пространстве по X
     */
    public int posX;
    /**
     * Положение персонажа в пространстве по Y
     */
    public int posY;

    public Player() {
        String name = "../data/player.png";
        imageSrc = new ImageIcon(getClass().getResource(name)).getImage();
    }



    @Override
    public void render(Graphics g) {
        g.drawImage(imageSrc, posX, posY, null);
    }
}

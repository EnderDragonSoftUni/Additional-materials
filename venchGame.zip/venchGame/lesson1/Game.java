package venchGame.lesson1;

/**
 * Created by oxana_bs on 1.7.2016 г..
 */

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Основной класс игры
 */
public class Game implements Runnable {

    /**
     * Отвечает за запуск или остановку игры
     */
    private boolean running;

    /**
     * Время шага таймера в игре
     */
    protected int timeDelay = 100;

    /**
     * Холст
     */
    protected Canvas canvas;

    /**
     * Карта
     */
    protected GemaMap map;

    /**
     * Персонаж нашей игры
     */
    protected Player player;

    /**
     * Отвечает за запуск игры
     */
    public void start() {
        if (running) {
            return;
        }
        running = true;
        canvas = new Canvas();
        map = new GemaMap();
        player = new Player();
        new Thread(this).start();
    }

    /**
     * Остановка игры
     */
    public void stop() {
        running = false;
    }

    /**
     * Получить ссылку на холст игры
     *
     * @return
     */
    public Canvas getCanvas() {
        return canvas;
    }


    @Override
    public void run() {
        while (running) {
            try {
                TimeUnit.MILLISECONDS.sleep(timeDelay);
            } catch (InterruptedException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            }
            update();
        }
    }

    /**
     * Вызывается по таймеру игры
     */
    protected void update() {
        //добавляем на холст   элементы карты
        canvas.removeRenders();
        int mapW = map.getWidth(),
                mapH = map.getHeight(),
                x, y, tileId;
        for (y = 0; y < mapH; y++) {
            for (x = 0; x < mapW; x++) {
                tileId = map.getTileId(x, y);
                //простейшая реализация выбора изображения для плитки
                canvas.addRender(new BaseTile((tileId == 2) ? "../data/black.png" : "../data/tile7.png", x * BaseTile
                        .SIZE, y * BaseTile.SIZE));
            }
        }

        //добавляем персонажа
        canvas.addRender(player);
        //изменяем положение персонажа
        player.posX++;
        player.posY++;
        //вызываем перерисовку холста
        canvas.repaint();
    }
}

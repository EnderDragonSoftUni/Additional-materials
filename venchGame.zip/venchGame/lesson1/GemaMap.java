package venchGame.lesson1;

/**
 * Класс карты игры.
 * По сути, карта является многомерным числовым массивом.
 * Массив можно хранить в виде   переменной,
 * а можно загружать из файла.
 */
public class GemaMap {

    private int[][] map;

    public GemaMap() {
        map = new int[][]{
                {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                {1, 2, 1, 2, 2, 2, 2, 2, 2, 1},
                {1, 2, 1, 2, 2, 2, 2, 2, 2, 1},
                {1, 2, 2, 2, 2, 2, 2, 2, 2, 1},
                {1, 2, 2, 2, 2, 2, 2, 2, 2, 1},
                {1, 2, 2, 2, 2, 2, 2, 2, 2, 1},
                {1, 2, 2, 2, 2, 1, 2, 2, 2, 1},
                {1, 2, 2, 2, 2, 1, 2, 2, 2, 1},
                {1, 2, 2, 2, 2, 1, 2, 2, 2, 1},
                {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        };
    }

    /**
     * Проверка наличия плитки на карте
     *
     * @param x
     * @param y
     * @return
     */
    public boolean hasTile(int x, int y) {
        return (x >= 0 && y >= 0 && y < getHeight() && x < getWidth());
    }

    /**
     * Получить ИД плитки
     *
     * @param x
     * @param y
     * @return
     */
    public int getTileId(int x, int y) {
        return hasTile(x, y) ? map[y][x] : 0;
    }

    /**
     * Количество плиток на карте по высоте
     *
     * @return
     */
    public int getHeight() {
        return map.length;
    }

    /**
     * Количество плиток на карте по ширине
     *
     * @return
     */
    public int getWidth() {
        return map[0].length;
    }
}
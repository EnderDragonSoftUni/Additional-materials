package venchGame.lesson1;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

/**
 * Created by oxana_bs on 2.7.2016 г..
 */
public /**
 * Базовый элемент отображения плитки карты
 */
class BaseTile implements IRenderToCanvas {
    /**
     * Размер плитки - ширина, высота
     */
    final public static int SIZE = 40;

    /**
     * Буфер загруженных изображений
     */
    private static HashMap<String, Image> images = new HashMap();

    /**
     * Имя изображения
     */
    public String image;
    /**
     * положение плитки по оси X
     */
    public int posX;
    /**
     * положение плитки по оси Y
     */
    public int posY;

    public BaseTile(String image, int posX, int posY) {
        this.image = image;
        this.posX = posX;
        this.posY = posY;
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(getImage(image), posX, posY, SIZE, SIZE, null);
    }

    /**
     * Вернет изображение по ссылке.
     * @param name
     * @return
     */
    public static Image getImage(String name) {
        if(images.get(name) == null) {
            images.put(name, new ImageIcon(BaseTile.class.getResource(name)).getImage());
        }
        return images.get(name);
    }
}

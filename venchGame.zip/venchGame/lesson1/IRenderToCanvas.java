package venchGame.lesson1;

/**
 * Created by oxana_bs on 1.7.2016 г..
 */
import java.awt.Graphics;

/**
 * Интерфейс дает гарантию реализации в объекте метода обрисовки на холсте
 */
public interface IRenderToCanvas {
    void render(Graphics g);
}

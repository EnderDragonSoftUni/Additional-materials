/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson3;

import javax.swing.*;
import java.awt.*;

/**
 * Класс персонажа игры.
 */
public class Player implements IRenderToConvas {

    /**
     * Изображение персонажа.
     */
    protected Image imageSrc;
    /**
     * Положение персонажа в пространстве по X.
     */
    public int posX;
    /**
     * Положение персонажа в пространстве по Y.
     */
    public int posY;

    /**
     * Скорость персонажа перемещения по карте.
     */
    public int speed = 5;

    /**
     * Указывает на передвижение персонажа  по оси X.
     * 1 - движение вправо, -1 - движение влево, 0 - нет движения.
     */
    public int directionX = 0;
    /**
     * Указывает на передвижение персонажа  по оси Y.
     * 1 - движение вниз, -1 - движение вверх, 0 - нет движения.
     */
    public int directionY = 0;

    /**
     * Размер персонажа по ширине.
     * Нужно знать для вычисления возможности прохождения по карте.
     */
    public int width = 30;

    /**
     * Размер персонажа по высоте.
     * Нужно знать для вычисления возможности прохождения по карте.
     */
    public int height = 30;

    /**
     * Указывает статическое положение при визуализации по оси X.
     */
    public int posRenderX;

    /**
     * Указывает статическое положение при визуализации по оси Y.
     */
    public int posRenderY;

    public Player() {
        String name = "../data/player.png";
        imageSrc = new ImageIcon(getClass().getResource(name)).getImage();
    }


    @Override
    public void render(Graphics g) {
        //используем статическое позиционирование
        g.drawImage(imageSrc, posRenderX, posRenderY, width, height, null);
    }
}

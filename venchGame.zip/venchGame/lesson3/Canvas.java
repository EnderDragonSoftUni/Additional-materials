/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson3;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Данный класс является основным холстом, где будет отображаться вся графическая составляющая игры.
 */
public class Canvas extends JPanel {

    /**
     * Основное изображение для рисования.
     * Осуществляет буферизацию изображений (избавляет от мерцания).
     */
    protected Image bufer = null;

    /**
     * Фон холста по умолчанию.
     */
    protected Color backGround = Color.black;

    /**
     * Список элементов, которые необходимо нарисовать на холсте.
     */
    protected ArrayList<IRenderToConvas> renders = new ArrayList<IRenderToConvas>();

    /**
     * Добавить элемент для рисования.
     *
     * @param render
     */
    public void addRender(IRenderToConvas render) {
        renders.add(render);
    }

    /**
     * Очищает список обрисовываемых элементов.
     */
    public void removeRenders() {
        renders.clear();
    }

    /**
     * Отвечает за вывод  графики на компоненте.
     *
     * @param g
     */
    public void paintWorld(Graphics g) {
        g.clearRect(0, 0, getWidth(), getHeight());
        g.setColor(backGround);
        g.fillRect(0, 0, getWidth(), getHeight());

        for (IRenderToConvas render : renders) {
            render.render(g);
        }
    }

    /**
     * Переопределяем метод обрисовки компонента.
     *
     * @param g
     */
    @Override
    public void paint(Graphics g) {
        super.paint(g);

        if (bufer == null) {
            bufer = createImage(getWidth(), getHeight());
        }
        //рисуем мир!
        paintWorld(bufer.getGraphics());
        g.drawImage(bufer, 0, 0, null);
    }
}

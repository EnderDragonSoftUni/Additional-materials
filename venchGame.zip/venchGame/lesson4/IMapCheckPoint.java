/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson4;

/**
 * Данный интерфейс передается алгоритму поиска пути на карте и осуществляет 
 * проверку возможности прохождения по плитке.
 * Использование интерфейса дает большую гибкость в реализации правил прохода.
 */
public interface IMapCheckPoint {
    /**
     * Проверка на прохождение точки.
     * @param x
     * @param y
     * @return 
     */
    boolean check(int x, int y);
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson4;

import java.awt.Point;
import java.util.ArrayList;

/**
 * Класс реализует алгоритм поиска пути на карте.
 * В основе алгоритма стоит пузырьковый метод поиска.
 * Поиск выполняется до тех пор, пока есть потенциально возможные точки в списке un.
 */
class MapFindingPath {

    /**
     * Ссылка на объект осуществляющий проверку прохождения.
     */
    protected IMapCheckPoint checkPoint;

    /**
     * Поиск был пройден до конца.
     */
    protected boolean toEnd;

    /**
     * Путь.
     */
    protected MapPath path;

    /**
     * Динамический список потенциально возможных точек пути до цели.
     */
    protected ArrayList<PathPoint> un;

    /**
     * Динамический список уже найденных точек.
     */
    protected ArrayList<PathPoint> pt;

    /**
     * Установить объект проверки прохождения.
     *
     * @param checkPoint
     */
    public void setcheckPoint(IMapCheckPoint checkPoint) {
        this.checkPoint = checkPoint;
    }

    public MapPath getPath() {
        return path;
    }

    /**
     * Осуществляет алгоритм поиска
     *
     * @param startx начальная точка плитки по X
     * @param starty начальная точка плитки по Y
     * @param endx   конечная тока плитки по X
     * @param endy   конечная тока плитки по Y
     * @return
     */
    public boolean findPath(int startx, int starty, int endx, int endy) {
        toEnd = false;
        path = new MapPath();
        pt = new ArrayList<PathPoint>();
        un = new ArrayList<PathPoint>();

        PathPoint p = new PathPoint(startx, starty, -1, -1, Math.abs(startx - endx) + Math.abs(starty - endy), true);
        pt.add(p);
        un.add(p);
        PathPoint node;
        while (un.size() > 0) {
            //Берем первую потенциальную точку из списка.
            node = un.get(0);
            un.remove(0);

            //проверяяем дошли ли мы до конца.
            if (node.x == endx && node.y == endy) {
                //создаем путь
                makePatch(node);
                toEnd = true;
                break;
            } else {
                //Помечаем точку как просмотренную, что бы не уйти в вечный цикл
                node.visited = true;
                //ставим все потенциально возможные точки
                addNode(node, node.x + 1, node.y, endx, endy);
                addNode(node, node.x - 1, node.y, endx, endy);
                addNode(node, node.x, node.y + 1, endx, endy);
                addNode(node, node.x, node.y - 1, endx, endy);
                //при желании можно добавить варианты по диагонали
            }
        }

        pt = null;
        un = null;

        return toEnd;
    }

    /**
     * Создаем путь из отобранных точек.
     *
     * @param node
     */
    protected void makePatch(PathPoint node) {
        path.clear();
        while (node.px != -1) {
            path.add(new Point(node.x, node.y));
            for (PathPoint p : pt) {
                if (p.x == node.px && p.y == node.py) {
                    node = p;
                    break;
                }
            }
        }
    }

    /**
     * Добавляем потенциальную точку.
     *
     * @param node
     * @param x
     * @param y
     * @param endx
     * @param endy
     */
    protected void addNode(PathPoint node, int x, int y, int endx, int endy) {
        //проверяем возможность прохождения по точке.
        if (checkPoint.check(x, y)) {
            //Определяем "стоимость", расстояние до конечной точки
            int cost = Math.abs(x - endx) + Math.abs(y - endy);
            PathPoint px = new PathPoint(x, y, node.x, node.y, cost, false);
            PathPoint old = null;
            //проверяем точку на уникальность
            for (PathPoint p : pt) {
                if (p.x == px.x && p.y == px.y) {
                    old = p;
                    break;
                }
            }

            //Точка уникальна, или стоимость новой точки меньше старой
            if (old == null || old.cost > cost) {
                pt.add(px);
                int i = 0;
                for (; i < un.size(); i++) {
                    //Ставим точку с меньшой стоимостью в приоритет обхода потенциальных точек.
                    if (cost < un.get(i).cost) {
                        un.add(i, px);
                        break;
                    }
                }
                //если точка не была вставлена, ставим ее вконец
                if (i >= un.size()) {
                    un.add(px);
                }
            }
        }

    }
}

/**
 * Вспомогательный класс хранения информации о точке.
 */
class PathPoint {

    public int x, y, px, py, cost;
    public boolean visited;


    public PathPoint(int x, int y, int px, int py, int cost, boolean visited) {

        setData(x, y, px, py, cost, visited);
    }

    final public void setData(int x, int y, int px, int py, int cost, boolean visited) {
        this.x = x;
        this.y = y;
        this.px = px;
        this.py = py;
        this.cost = cost;
        this.visited = visited;

    }
} 

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson4;

/**
 *
 *  Карта 2.
 */
public class Map2 extends GemaMap {
     public Map2() {
        map = new int[][]{ 
            {1,1,1,1,1,1,1},
            {1,2,2,2,2,2,1},
            {1,2,1,1,1,2,1},
            {1,2,1,4,1,2,1},
            {1,2,2,2,2,2,1},
            {1,1,1,1,1,1,1}
        };
    }   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package venchGame.lesson7;

/**
 * Дает возможность создавать анонимные классы, 
 * предоставляя возможность описывать объекты в методе launch.
 */
public class AdapterSpriteUnit extends SpriteUnit {
    public AdapterSpriteUnit() {
        launch();
    }
    
    /**
     * Специальный метод для инициализации объекта.
     */
    public void launch() { }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package venchGame.lesson7;

import java.awt.*;

/**
 *
 * Получает плитку по принципу поиска куска на большом изображении.
 */
public class SpriteTile extends BaseTile { 
    public int width;
    public int height;
    public int offsetX;
    public int offsetY;
    
    public SpriteTile(String image, int posX, int posY, int width, int height, int offsetX, int offsetY, boolean isWalkable, int door) {
        super(image, posX, posY, isWalkable, door);
        this.width = width;
        this.height = height;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
    }
    
    @Override
    public void render(Graphics g) {   
        int renderX = posX,
            renderY = posY;
        if(Game.USE_ISO) {
             renderX = (posX - posY); 
             renderY = (posX + posY) / 2;  
        }
  
        g.drawImage(getImage(image), renderX + Game.OFFSET_MAP_X, renderY, renderX + width + Game.OFFSET_MAP_X, renderY + height, offsetX, offsetY, offsetX + width, offsetY + height, null);
    }
}

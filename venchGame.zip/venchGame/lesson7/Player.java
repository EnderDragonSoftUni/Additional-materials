/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson7;

 

/**
 * Класс персонажа игры. 
 */
public class Player extends BaseActionSpriteUnit { 
     
    
    public Player() {
        String name = "../data/hero/warr.png";
        offsetRenderY = - 74;
        offsetRenderX = - 27;
        drawWidth = 128;
        drawHeight = 128;
        init(name);
        actionStand();
        turnRight();
    }  
}

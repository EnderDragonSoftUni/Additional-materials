/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson7;

/**
 * Класс бота. 
 */
public class Bot extends BaseActionSpriteUnit {
    
    /**
     * Положение объекта приследования по X
     */
    public int targetX;
    /**
     * Положение объекта приследования по Y
     */
    public int targetY;
    
    public Bot() {
        //уменьшаем скорость
        //что бы он не слишком быстро шел за нашим персонажем
        speed = 2;
        offsetRenderY = - 74;
        offsetRenderX = - 27;
        drawWidth = 128;
        drawHeight = 128; 
        String name = "../data/bot/zombie.png";
        init(name);
        actionStand();
        turnRight(); 
    }  
    
    /**
     * Обновляем точку преследования.
     * @param targetX
     * @param targetY
     * @return 
     */
    public boolean updateTarget(int targetX, int targetY) {
        if(targetX != this.targetX || targetY != this.targetY) {
            this.targetX = targetX;
            this.targetY = targetY;
            return true;
        }
        return false;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package venchGame.lesson7;

import java.awt.Graphics; 

/**
 *
 * Класс реализует возможность управления па кадровой анимацией при помощи спрайтов.
 */
public abstract class SpriteUnit extends Unit {
    
    /**
     * Ширина картинки на полотне.
     */
    protected int frameWidth = 128;
    
    /**
     * Высота картинки на полотне.
     */
    protected int frameHeight = 128;
    
    /**
     * Положение на картинке по X на полотне.
     */
    protected int frameX = 0;
    
    /**
     * Положение на картинке по Y на полотне.
     */
    protected int frameY = 0;
    
    /**
     * Минимальная позиция по X при зацикливании.
     */
    protected int frameMinX = 0;
    
    /**
     * Минимальная позиция по Y при зацикливании.
     */
    protected int frameMinY = 0;
    
    /**
     * Максимальная позиция по X при зацикливании.
     */
    protected int frameMaxX = 0;
    
    /**
     * Максимальная позиция по Y при зацикливании.
     */
    protected int frameMaxY = 0;
    
    /**
     * Используем для рисования свои размеры, так они могут отличатся от @var width  используемых для расчета.
     */
    protected int drawWidth = 100;
    
    /**
     * Используем для рисования свои размеры, так они могут отличатся от @var height  используемых для расчета.
     */
    protected int drawHeight = 100;
    
    @Override
    public void render(Graphics g) {  
        //перед рисованием вызываем метод обновления
        update();
        //используем статическое позиционирование
        int renderX = posRenderX,
            renderY = posRenderY;
        if(Game.USE_ISO) {
             renderX = (posRenderX - posRenderY); 
             renderY = (posRenderX + posRenderY) / 2;  
        }
         
        g.drawImage(imageSrc, 
                    renderX + Game.OFFSET_MAP_X + offsetRenderX, 
                    renderY + offsetRenderY, 
                    renderX + drawWidth + Game.OFFSET_MAP_X + offsetRenderX, 
                    renderY + drawHeight + offsetRenderY, 
                    frameX * frameWidth, 
                    frameY * frameHeight, 
                    frameX * frameWidth + frameWidth, 
                    frameY * frameHeight + frameHeight, null);
    }
    
    @Override
    protected void update() {
        //зацикливаем переход по кадрам
        frameX ++;
        if(frameX > frameMaxX) {
            frameX = frameMinX;
        }
        frameY ++;
        if(frameY > frameMaxY) {
            frameY = frameMinY;
        }
        super.update();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package venchGame.lesson7;

/**
 * Класс играет роль упаковки для SpriteUnit создавая методы однотипных действий - повороты, ходьба, стояние.
 */
public abstract class BaseActionSpriteUnit extends SpriteUnit {

    /**
     * Действие шагания персонажа.
     */
    public void actionStep() {
        if (frameMaxX == 10 && frameMinX == 4) {
            return;
        }
        frameMaxX = 10;
        frameMinX = frameX = 4;
    }

    /**
     * Действие стояния на месте персонажа.
     */
    public void actionStand() {
        if (frameMaxX == 3 && frameMinX == 0) {
            return;
        }
        frameMinX = frameX = 0;
        frameMaxX = 3;
    }

    /**
     * Поворот наверх.
     */
    public void turnTop() {
        frameMinY = frameMaxY = frameY = 3;
    }

    /**
     * Поворот налево.
     */
    public void turnLeft() {
        frameMinY = frameMaxY = frameY = 1;
    }

    /**
     * Поворот направо.
     */
    public void turnRight() {
        frameMinY = frameMaxY = frameY = 5;
    }

    /**
     * Поворот вниз.
     */
    public void turnBoth() {
        frameMinY = frameMaxY = frameY = 7;
    }

    @Override
    protected void update() {
        super.update();
        //указываем действие и поворот по умолчанию
        if (directionX == 0 && directionY == 0) {
            actionStand();
        } else if (directionX == 0 && directionY == 1) {
            turnBoth();
            actionStep();
        } else if (directionX == 0 && directionY == -1) {
            turnTop();
            actionStep();
        } else if (directionX == 1 && directionY == 0) {
            turnRight();
            actionStep();
        } else if (directionX == -1 && directionY == 0) {
            turnLeft();
            actionStep();
        }
    }
}

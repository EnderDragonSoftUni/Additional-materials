/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson2;

import java.awt.Graphics;

/**
 * Интерфейс дает гарантию реализации в объекте метода обрисовки на холсте.
 */
public interface IRenderToCanvas {
    void render(Graphics g);
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson6;

import java.awt.Graphics;

/**
 * Интерфейс дает гарантию реализации в объекте метода обрисовки на холсте.
 */
public interface IRenderToConvas {
    void render(Graphics g);
    int getDeep();
}

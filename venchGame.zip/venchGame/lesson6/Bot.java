/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson6;

/**
 * Класс бота.
 * @author vench
 */
public class Bot extends Unit {
    
    /**
     * Положение объекта приследования по X
     */
    public int targetX;
    /**
     * Положение объекта приследования по Y
     */
    public int targetY;
    
    public Bot() {
        //уменьшаем скорость
        //что бы он не слишком быстро шел за нашим персонажем
        speed = 2;
        offsetRenderY = - 5;
        offsetRenderX =  20;
        String name = "../data/bot-zombie.png";
        init(name);
         
    }  
    
    /**
     * Обновляем точку преследования.
     * @param targetX
     * @param targetY
     * @return 
     */
    public boolean updateTarget(int targetX, int targetY) {
        if(targetX != this.targetX || targetY != this.targetY) {
            this.targetX = targetX;
            this.targetY = targetY;
            return true;
        }
        return false;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package venchGame.lesson6;

import java.awt.*;

/**
 * Класс для отображения плитки на карте,
 * изображение плитки берется как кусок из большого изображения.
 */
public class SpriteTile extends BaseTile {

    /**
     * Ширина изображения на изображении.
     */
    public int width;

    /**
     * Высота изображения на изображении.
     */
    public int height;

    /**
     * Отступ в изображении по оси X.
     */
    public int offsetX;

    /**
     * Отступ в изображении по оси Y.
     */
    public int offsetY;

    public SpriteTile(String image, int posX, int posY, int width, int height, int offsetX, int offsetY, boolean
            isWalkable, int door) {
        super(image, posX, posY, isWalkable, door);
        this.width = width;
        this.height = height;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
    }

    @Override
    public void render(Graphics g) {
        int renderX = posX,
                renderY = posY;
        if (Game.USE_ISO) {
            renderX = (posX - posY);
            renderY = (posX + posY) / 2;
        }

        g.drawImage(getImage(image), renderX + Game.OFFSET_MAP_X, renderY, renderX + width + Game.OFFSET_MAP_X,
                renderY + height, offsetX, offsetY, offsetX + width, offsetY + height, null);
    }
}

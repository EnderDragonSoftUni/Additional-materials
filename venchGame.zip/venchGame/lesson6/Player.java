/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson6;

 

/**
 * Класс персонажа игры. 
 */
public class Player extends Unit { 
     
    
    public Player() {
        offsetRenderY = - 5;
        offsetRenderX =  20;
        String name = "../data/player.png";
        init(name);
    } 
}

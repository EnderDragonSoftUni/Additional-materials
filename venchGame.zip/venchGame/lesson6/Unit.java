/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson6;

import javax.swing.*;
import java.awt.*;

/**
 * Класс реализует функцинал отображения единицы...
 */
public abstract class Unit implements IRenderToConvas {

    /**
     * Изображение объекта.
     */
    protected Image imageSrc;
    /**
     * Положение персонажа в пространстве по X.
     */
    public int posX;
    /**
     * Положение персонажа в пространстве по Y.
     */
    public int posY;

    /**
     * Скорость персонажа перемещения по карте.
     */
    public int speed = 4;

    /**
     * Указывает на передвижение персонажа  по оси X.
     * 1 - движение вправо, -1 - движение влево, 0 - нет движения.
     */
    public int directionX = 0;
    /**
     * Указывает на передвижение персонажа  по оси Y.
     * 1 - движение вниз, -1 - движение вверх, 0 - нет движения.
     */
    public int directionY = 0;

    /**
     * Размер персонажа по ширине.
     * Нужно знать для вычисления возможности прохождения по карте.
     */
    public int width = 32;

    /**
     * Размер персонажа по высоте.
     * Нужно знать для вычисления возможности прохождения по карте.
     */
    public int height = 32;

    /**
     * Указывает статическое положение при визуализации по оси X.
     */
    public int posRenderX;

    /**
     * Указывает статическое положение при визуализации по оси Y.
     */
    public int posRenderY;

    /**
     * Поле хранит путь движения персонажа.
     */
    public MapPath mapPath;

    /**
     * Отступ при рисовании объекта на карте, что бы он занял середину клетки по X.
     */
    public int offsetRenderX = 0;

    /**
     * Отступ при рисовании объекта на карте, что бы он занял середину клетки по Y.
     */
    public int offsetRenderY = 0;

    public void init(String name) {
        imageSrc = new ImageIcon(getClass().getResource(name)).getImage();
    }


    @Override
    public int getDeep() {
        return posY * Canvas.LAYER_DEEP1 + posX;
    }


    @Override
    public void render(Graphics g) {
        //перед рисованием вызываем метод обновления
        update();
        //используем статическое позиционирование
        int renderX = posRenderX,
                renderY = posRenderY;
        if (Game.USE_ISO) {
            renderX = (posRenderX - posRenderY);
            renderY = (posRenderX + posRenderY) / 2;
        }
        g.drawImage(imageSrc, renderX + offsetRenderX + Game.OFFSET_MAP_X, renderY + offsetRenderY, width, height,
                null);
    }

    /**
     * Метод обновляет данные о положении игрока на карте.
     */
    protected void update() {
        if (mapPath != null && mapPath.hasNext()) {
            if (mapPath.p == null) {
                mapPath.startMove(posX, posY);
            } else {
                mapPath.nextPos(speed);
                if (posX != mapPath.p.x) {
                    directionX = (posX > mapPath.p.x) ? -1 : 1;
                } else {
                    directionX = 0;
                }
                if (posY != mapPath.p.y) {
                    directionY = (posY > mapPath.p.y) ? -1 : 1;
                } else {
                    directionY = 0;
                }
            }
        } else {
            directionX = 0;
            directionY = 0;
        }

    }
}

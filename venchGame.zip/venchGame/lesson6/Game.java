/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson6;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.awt.Graphics;


/**
 * Основной класс игры
 */
public class Game implements Runnable {

    /**
     * Указание на использование изометрической проекции при рисовании объектов.
     */
    final public static boolean USE_ISO = true;

    /**
     * Отступ при рисовании справа.
     */
    final public static int OFFSET_MAP_X = 320;//10 клеток 32 * 10

    /**
     * Отвечает за запуск или остановку игры
     */
    private boolean running;

    /**
     * Время шага таймера в игре
     */
    protected int timeDelay = 100;

    /**
     * Холст
     */
    protected Canvas canvas;

    /**
     * Карта
     */
    protected GemaMap map;

    /**
     * Персонаж нашей игры
     */
    protected Player player;

    /**
     * Список ботов.
     */
    protected ArrayList<Bot> bots;


    /**
     * Реализация класса обработчика  событий клавиатуры.
     * Отслеживая нажатие клавиш мы задаем направление движения персонажа.
     */
    protected KeyAdapter keyListener = new KeyAdapter() {

        @Override
        public void keyPressed(KeyEvent e) {

            if (e.getKeyCode() == 37) {
                player.directionX = -1;
            }
            if (e.getKeyCode() == 39) {
                player.directionX = 1;
            }
            if (e.getKeyCode() == 38) {
                player.directionY = -1;
            }
            if (e.getKeyCode() == 40) {
                player.directionY = 1;
            }

        }

        @Override
        public void keyReleased(KeyEvent e) {
            if (e.getKeyCode() == 37 || e.getKeyCode() == 39) {
                player.directionX = 0;
            }
            if (e.getKeyCode() == 38 || e.getKeyCode() == 40) {
                player.directionY = 0;
            }


        }

    };

    /**
     * Реализация класса обработчика событий мыши.
     * Получает координаты щелчка по карте и определяет путь движения персонажа.
     */
    protected MouseAdapter mouseListener = new MouseAdapter() {

        @Override
        public void mouseClicked(MouseEvent e) {

            //получаем начальные координаты плиток
            int startTileX, startTileY;
            if (USE_ISO) {
                //обратная функция рассчета изометрический координат
                int _offX = (e.getX() - Game.OFFSET_MAP_X),
                        _y = (2 * e.getY() - _offX) / 2,
                        isoX = Math.round((_offX + _y) / BaseTile.SIZE) + 0 - 0 - 0,
                        isoY = Math.round((_y + BaseTile.SIZE / 2) / BaseTile.SIZE) + 0 - 0;
                startTileX = isoX + Math.round((Math.abs(player.posX - player.posRenderX)) / BaseTile.SIZE);
                startTileY = isoY + Math.round((Math.abs(player.posY - player.posRenderY)) / BaseTile.SIZE);
            } else {
                startTileX = (int) Math.floor((Math.abs(player.posX - player.posRenderX) + e.getX()) / BaseTile.SIZE);
                startTileY = (int) Math.floor((Math.abs(player.posY - player.posRenderY) + e.getY()) / BaseTile.SIZE);
            }
            //создаем путь
            if (tileIsWalkable(startTileX, startTileY)) {
                MapPath mapPath = makePath(player.posX / BaseTile.SIZE, player.posY / BaseTile.SIZE, startTileX,
                        startTileY);
                player.mapPath = mapPath;
            }
        }
    };


    /**
     * Отвечает за запуск игры
     */
    public void start() {
        if (running) {
            return;
        }
        running = true;
        canvas = new Canvas();

        player = new Player();
        //Ставим карту
        setMap(1);

        //устанавливаем ботов
        bots = new ArrayList<>();
        Bot bot;
        for (int i = 0; i < 4; i++) {
            bot = new Bot();
            bot.posX = bot.posRenderX = (6 + i) * BaseTile.SIZE;
            bot.posY = bot.posRenderY = 7 * BaseTile.SIZE;
            bots.add(bot);
        }

        //устанавливаем обработчики событий        
        setListener();

        new Thread(this).start();
    }

    /**
     * Создаем путь до указанной точке.
     *
     * @param startX начальная точка по X.
     * @param startY начальная точка по Y.
     * @param endX   конечная точка по X.
     * @param endY   конечная точка по Y.
     * @return
     */
    public MapPath makePath(int startX, int startY, int endX, int endY) {
        MapFindingPath mfp = new MapFindingPath();
        mfp.setcheckPoint(new IMapCheckPoint() {
            @Override
            public boolean check(int x, int y) {
                if (tileIsWalkable(x, y)) {
                    //запрещаем проходить между зомби
                    for (Bot bot : bots) {
                        if (bot.posX / BaseTile.SIZE == x && bot.posY / BaseTile.SIZE == y) {
                            return false;
                        }
                    }
                    return true;
                }
                return false;
            }
        });

        if (mfp.findPath(startX, startY, endX, endY)) {
            return mfp.getPath();
        }

        return null;
    }

    /**
     * Метод отвечает за установку карты.
     *
     * @param mapId Номер карты.
     */
    public void setMap(int mapId) {
        if (mapId == 2) {
            map = new Map2();
        } else {
            map = new Map1();
        }

        //удаляем путь при смене карты
        player.mapPath = null;

        //Данные хранения положения персонажа могут быть реализованы в классе карты
        player.posX = BaseTile.SIZE;
        player.posY = BaseTile.SIZE;
        //устанавливаем статическое позиционирование
        player.posRenderX = BaseTile.SIZE;
        player.posRenderY = BaseTile.SIZE;
    }

    /**
     * Остановка игры.
     */
    public void stop() {
        //удаляем обработчики событий
        unSetListener();
        running = false;
    }

    /**
     * Получить ссылку на холст игры
     *
     * @return @Canvas
     */
    public Canvas getCanvas() {
        return canvas;
    }


    @Override
    public void run() {
        while (running) {
            try {
                TimeUnit.MILLISECONDS.sleep(timeDelay);
            } catch (InterruptedException ex) {
                Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            }
            update();
        }
    }


    /**
     * Установить обработчики  событий.
     */
    public void setListener() {
        canvas.setFocusable(true);//нужно указать для получения событий с клавиатуры
        canvas.addKeyListener(keyListener);
        canvas.addMouseListener(mouseListener);
    }

    /**
     * Удалить обработчики  событий.
     */
    public void unSetListener() {
        canvas.setFocusable(false);//убираем    фокус
        canvas.removeKeyListener(keyListener);
        canvas.removeMouseListener(mouseListener);
    }

    /**
     * Конец игры.
     */
    public void gameOver() {
        canvas.addRender(new Unit() {
            @Override
            public void render(Graphics g) {
                init("../data/game-over.png");
                width = 640;
                height = 480;
                g.drawImage(imageSrc, 0, 0, width, height, null);
            }

            @Override
            public int getDeep() {
                //поверх всех
                return Integer.MAX_VALUE;
            }
        });
        canvas.repaint();
        stop();
    }

    /**
     * Вызывается по таймеру игры
     */
    protected void update() {

        checkingChangeMap();

        //добавляем на холст   элементы карты 
        canvas.removeRenders();
        int mapW = map.getWidth(),
                mapH = map.getHeight(),
                x, y, tileId,
                //ширина и высота   квадрата  - рамки в тайлах
                //размер зависит от экрана игры
                widthTile = 13,
                heightTile = 15,
                //центральная точка отображаемого квадрата карты
                cWidthTile = widthTile / 2 - 1,
                cHeightTile = heightTile / 2 - 1,
                //здвиг карты
                offsetX = (player.posX - player.posRenderX) % BaseTile.SIZE,
                offsetY = (player.posY - player.posRenderY) % BaseTile.SIZE,
                //ограничиваем выводимые плитки
                startTileX = (int) Math.floor(Math.abs(player.posX - player.posRenderX) / BaseTile.SIZE),
                startTileY = (int) Math.floor(Math.abs(player.posY - player.posRenderY) / BaseTile.SIZE),
                endTileX = widthTile + startTileX > mapW ? mapW : widthTile + startTileX,
                endTileY = heightTile + startTileY > mapH ? mapH : heightTile + startTileY;
        //определяем когда двигать карту - а когда должен двигаться  персонаж
        boolean movePlayerX = (player.posX / BaseTile.SIZE < cWidthTile || mapW - player.posX / BaseTile.SIZE <
                cWidthTile + 1),
                movePlayerY = (player.posY / BaseTile.SIZE < cHeightTile || mapH - player.posY / BaseTile.SIZE <
                        cHeightTile + 2);

        BaseTile tile;
        for (y = startTileY; y < endTileY; y++) {
            for (x = startTileX; x < endTileX; x++) {
                tileId = map.getTileId(x, y);
                tile = BaseTile.getTileById(tileId);

                tile.posX = (x - startTileX) * BaseTile.SIZE;
                tile.posY = (y - startTileY) * BaseTile.SIZE;
                tile.posX -= offsetX;
                tile.posY -= offsetY;

                canvas.addRender(tile);
            }
        }

        //добавляем ботов
        for (Bot bot : bots) {

            //проверяем - если бот достиг игрока игра закончена...
            if (bot.posX / BaseTile.SIZE == player.posX / BaseTile.SIZE &&
                    bot.posY / BaseTile.SIZE == player.posY / BaseTile.SIZE) {
                gameOver();
                return;
            }


            //рисуем бота когда он в зоне видемости
            if (bot.posX >= startTileX * BaseTile.SIZE &&
                    bot.posX <= endTileX * BaseTile.SIZE &&
                    bot.posY >= startTileY * BaseTile.SIZE &&
                    bot.posY <= endTileY * BaseTile.SIZE) {
                //обновляем точку преследования.
                if (bot.updateTarget(player.posX / BaseTile.SIZE, player.posY / BaseTile.SIZE)) {
                    bot.mapPath = makePath(bot.posX / BaseTile.SIZE, bot.posY / BaseTile.SIZE, bot.targetX, bot
                            .targetY);

                } else
                    //изменяем положение
                    if (bot.directionX != 0 || bot.directionY != 0) {
                        bot.posX += bot.directionX * bot.speed;
                        bot.posY += bot.directionY * bot.speed;
                    }

                bot.posRenderX = (bot.posX - startTileX * BaseTile.SIZE) - offsetX;
                bot.posRenderY = (bot.posY - startTileY * BaseTile.SIZE) - offsetY;
                canvas.addRender(bot);
            }
        }

        //добавляем персонажа
        canvas.addRender(player);
        //изменяем положение персонажа 
        //для этого мы должны сделать проверку на возможность движения.
        if ((player.directionX != 0 || player.directionY != 0) && accessMove()) {
            player.posX += player.directionX * player.speed;
            player.posY += player.directionY * player.speed;

            if (movePlayerX) {
                player.posRenderX += player.directionX * player.speed;
            }
            if (movePlayerY) {
                player.posRenderY += player.directionY * player.speed;
            }
        }


        //вызываем перерисовку холста
        canvas.repaint();
    }

    /**
     * Проверяем находиться ли пользователь на плитки с дверью.
     */
    public void checkingChangeMap() {
        int tileX = player.posX / BaseTile.SIZE,
                tileY = player.posY / BaseTile.SIZE,
                tileId = map.getTileId(tileX, tileY);
        BaseTile tile = BaseTile.getTileById(tileId);
        if (tile.door > 0) {
            setMap(tile.door);
        }
    }

    /**
     * Проверяем возможность персонажа переместится.
     * <p>
     * В данной реализации, может случится, что объект не достигает границы плитки, а идти уже не может.
     * Причина вероятно в значении скорости игрока (player.speed), она должна делить без остатка размер плитки.
     * В противном случаи остаток нужно прибавить к максимальному  значению right и down.
     *
     * @return
     */
    protected boolean accessMove() {
        int left, right, top, down;
        boolean isWalkable = true;

        //верх и низ
        //Находим вероятные точки плиток с учетом направления directionY
        left = (int) Math.ceil((player.posX) / BaseTile.SIZE);
        right = (int) Math.floor((player.posX + player.width - 1) / BaseTile.SIZE);
        top = (int) Math.ceil((player.posY + player.speed * player.directionY) / BaseTile.SIZE);
        down = (int) Math.floor((player.posY + player.height + player.speed * player.directionY - 1) / BaseTile.SIZE);
        //проверяем доступность направления по вершине правой и левой сверх (низу) - на тот случай если игрок
        // находится вне начала плитки по оси Х
        if (player.directionY == -1 && !(tileIsWalkable(left, top) && tileIsWalkable(right, top))) {
            isWalkable = false;
        } else if (player.directionY == 1 && !(tileIsWalkable(left, down) && tileIsWalkable(right, down))) {
            isWalkable = false;
        }
        //право и лево
        //Находим вероятные точки плиток с учетом направления directionX
        left = (int) Math.ceil((player.posX + player.speed * player.directionX) / BaseTile.SIZE);
        right = (int) Math.floor((player.posX + player.width + player.speed * player.directionX - 1) / BaseTile.SIZE);
        top = (int) Math.ceil((player.posY) / BaseTile.SIZE);
        down = (int) Math.floor((player.posY + player.height - 1) / BaseTile.SIZE);
        //проверяем доступность направления по вершине верха и низа лева (права) - на тот случай если игрок находится
        // вне начала плитки по оси Y
        if (player.directionX == -1 && !(tileIsWalkable(left, top) && tileIsWalkable(left, down))) {
            isWalkable = false;
        } else if (player.directionX == 1 && !(tileIsWalkable(right, top) && tileIsWalkable(right, down))) {
            isWalkable = false;
        }

        return isWalkable;
    }

    /**
     * Проверяем является ли плитка пригодной для прохождения персонажем.
     *
     * @param x
     * @param y
     * @return
     */
    protected boolean tileIsWalkable(int x, int y) {
        BaseTile tile = BaseTile.getTileById(map.getTileId(x, y));
        return (tile != null && tile.isWalkable);
    }

}

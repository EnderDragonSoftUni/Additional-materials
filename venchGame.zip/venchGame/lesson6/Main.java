/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson6;


/**
 * @author vench
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.start();

        javax.swing.JFrame f = new javax.swing.JFrame();
        f.setLayout(null);
        f.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        f.setResizable(false);
        //устанавливаем размер холста
        game.getCanvas().setBounds(0, 0, 640, 480);
        //ставим холст для отображения
        f.add(game.getCanvas());
        f.setTitle("Main6");
        f.setBounds(300, 300, 640, 480);
        f.setVisible(true);
    }
}

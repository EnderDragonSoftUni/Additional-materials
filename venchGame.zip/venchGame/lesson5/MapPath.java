/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package venchGame.lesson5;

import java.awt.Point;
import java.util.ArrayList;

/**
 * Класс хранит информацию пути перемещения элемента по карте.
 */
public class MapPath {
    /**
     * Список плиток по которым пролегает путь.
     */
    public ArrayList<Point> path;
    
    /**
     * Текущая точка. 
     */
    public Point p;
    
    /**
     * Текущая позиция точки.
     */
    protected int index = 0;
    
    public MapPath() {
        path = new ArrayList<Point>();
    }
    
    /**
     * Очистить путь.
     */
    public void clear() {
        path.clear();
    }
    
    /**
     * Добавить точку по который будет проходить путь.
     * @param p 
     */
    public void add(Point p) {
        path.add(p); 
    }
    
    /**
     * Указать начальную точку пути.
     * @param posX
     * @param posY 
     */
    public void startMove(int posX, int posY) {
        p = new Point(posX, posY);
        index = path.size()-1;
    }
    
    /**
     * Проверить существует ли следующая точка.
     * @return 
     */
    public boolean hasNext() {
       return (index > -1); 
    }
    
    /**
     * Перейти на следующую точку (в случаи если текущую уже прошли).
     * @param step
     * @return 
     */
    public Point nextPos(int step) {
        int x = path.get(index).x * BaseTile.SIZE,
            y = path.get(index).y * BaseTile.SIZE; 
        if(p.x != x)  {
            p.x += step * ((x < p.x) ? -1: 1);
        } 
        if(p.y != y)  {
            p.y += step * ((y < p.y) ? -1: 1);
        } 
            
        if(p.x == x && p.y == y) {
            index --; 
        } 
         
        
        return p;
    }
}
